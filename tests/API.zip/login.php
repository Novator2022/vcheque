<?php
echo "\n";
require __DIR__.'/../vendor/autoload.php';
// $host = 'http://virtual.check.bs'; // 'client_secret'=>'CSfswK0Y3OfMa44hVgL3RjnCPWIdIR0E3om3S9CZ',
$host = 'http://vcheque.enginecon.ru';
$id = 2;
$http = new GuzzleHttp\Client([
    'verify' => false
]);
$credentials = json_decode(json_encode([
    'client_id'=>'2',

    'client_secret'=>'9hCaFkOAczikOp8hIUv1foROMKuFl9UFqXBtrBWW',
    'email'=>'admin@vcheque.ru',
    'password'=>'vc123123'
]));
try{
    $response = $http->post($host.'/oauth/token', [
        'form_params' => [
            'grant_type' => 'password',
            'client_id' => $credentials->client_id,
            'client_secret' => $credentials->client_secret,
            'username' => $credentials->email,
            'password' => $credentials->password,
            'scope' => '',
        ],
    ],['debug'=>true]);

    $tokens = json_decode((string) $response->getBody());
    $headers = [
        'Accept' => 'application/json',
        'Authorization' => $tokens->token_type.' '.$tokens->access_token,
    ];
    echo "token expires in ".($tokens->expires_in/60).' minutes'."\n";
    $response = $http->get($host.'/api/cheque?status=request',[ 'headers' => $headers ]);
    $cheques = json_decode((string) $response->getBody(),true);
    $response = $http->get($host.'/api/cheque/'.$id,[ 'headers' => $headers ]);
    $cheque = json_decode((string) $response->getBody(),true);
    $cheque["status"]='success';
    $response = $http->put($host.'/api/cheque/'.$id,[ 'headers' => $headers,'form_params' => $cheque ]);
    $cheque = json_decode((string) $response->getBody(),true);
    print_r($cheque);
}
catch(\Exception $e){
    echo $e->getMessage()."\n";
}
?>
